(function (angular) {
	'use strict';

	angular.module('gux.formButtonOld', ['ui.router'])
		.directive('gxFormButtonOld', ['$state',
			function (state) {

				function GXFormButtonController(rootScope) {
					var self = this;
					if (self.stereotype === 'post') {
						self.type = "submit";
						self.label = "Gravar";
					} else if (self.stereotype === 'put') {
						self.type = "submit";
						self.label = "Atualizar";
					} else if (self.stereotype === 'get') {
						self.type = "submit";
						self.label = "Pesquisar";
					} else if (self.stereotype === 'clean') {
						self.type = "reset";
						self.label = "Limpar";
					} else if (self.stereotype === 'cancel') {
						self.type = "button";
						self.label = "Cancelar";
					} else if (self.stereotype === 'back') {
						self.type = "button";
						self.label = "Voltar";
					}
					self.lastState = rootScope.session.lastState;
				};

				var disabled = function (scope) {
					var disabled = false;
					try {
						var controller = scope.controller;
						var form = scope[controller.formName];
						if (form && (controller.stereotype === 'cancel' || controller.stereotype === 'back')) {
							disabled = !controller.lastState.name;
						}
					} catch (error) {
						disabled = false;
					}
					return disabled;
				};

				var click = function (scope, event) {

					var controller = scope.controller;
					var form = scope[controller.formName];

					if (!!form
						&& (controller.stereotype === 'post'
							|| controller.stereotype === 'put')) {
						if (scope[controller.formName].$invalid
							|| !scope[controller.formName].$valid) {
							return;
						}
					}

					if (controller.isOnClickDifined) {
						controller.onClick()(event);
					}

					if (controller.go) {
						state.go(controller.go);
					} else if (controller.lastState.name
						&& (scope.controller.stereotype === 'cancel'
							|| scope.controller.stereotype === 'back')) {
						state.go(controller.lastState.name);
					}

					if (form && scope.controller.stereotype === 'clean') {
						scope[controller.formName].$setPristine();
					}
				};

				function GXFormButtonLink(scope, element, attributes, controller) {

					controller.formName = $(element).closest('form').attr('name');

					controller.disabled = function () {
						return disabled(scope);
					}

					controller.click = function (event) {
						click(scope, event)
					}

					if (attributes.onClick) {
						controller.isOnClickDifined = true;
					}
				};

				return {
					restrict: 'E',
					replace: true,
					templateUrl: 'views/gx-form-button.html',
					scope: true,
					controller: ['$rootScope', GXFormButtonController],
					controllerAs: 'controller',
					bindToController: {
						stereotype: '@',
						go: '@',
						onClick: '&'
					},
					link: GXFormButtonLink
				};
			}]);

} (window.angular));
