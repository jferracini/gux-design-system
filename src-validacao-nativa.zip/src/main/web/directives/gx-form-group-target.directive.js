(function ($, angular) {

	'use strict';

	function gxFormGroupTargetLink($scope, element, attributes, controllers) {
		if (!element.attr('name')) {
			throw new Error('You must define name attribute for element ' + $('<span>').append(element).html());
		}
		var gxFormGroupController = controllers[0];
		var ngModelController = controllers[1];
		gxFormGroupController.registerNgModelController(ngModelController);
	}

	var gxFormGroupTargetDependencies = [
	];

	function gxFormGroupTargetDirective() {
		return {
			restrict: 'A',
			scope: false,
			require: ['^gxFormGroup', 'ngModel'],
			link: gxFormGroupTargetLink
		}
	}

	angular
		.module('gux.formGroupTarget', gxFormGroupTargetDependencies)
		.directive('gxFormGroupTarget', gxFormGroupTargetDirective);

} (window.$, window.angular));
