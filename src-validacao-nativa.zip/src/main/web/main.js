(function (angular) {

	'use strict';
	
	var guxToolboxDependencies = [
		'gux.tooltip',
		'gux.app',
		'gux.panel',
		'gux.form',
		'gux.formGroup',
		'gux.fieldset',
		'gux.formButton',
		'bw.paging'];

	angular.module('gux.toolbox', guxToolboxDependencies);

} (window.angular));