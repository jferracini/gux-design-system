(function ($, angular) {

	'use strict';

	var elementIndex = 1;

	function setName(self) {
		var inputElementName = null;
		if (!!self.name) {
			inputElementName = self.name;
		} else {
			inputElementName = 'gx-form-group-' + elementIndex++;
		}
		self.elementName = inputElementName;
	};

	function setType(self) {
		if (self.stereotype === 'number'
			|| self.stereotype === 'text'
			|| self.stereotype === 'email'
			|| self.stereotype === 'password'
			|| self.stereotype === 'url') {
			self.isInput = true;
		} else if (self.stereotype === 'textarea') {
			self.isTextarea = true;
		} else if (self.stereotype === 'date-time'
			|| self.stereotype === 'date'
			|| self.stereotype === 'date-month'
			|| self.stereotype === 'date-year') {
			self.isCalendar = true;
		} else if (self.stereotype === 'select') {
			self.isSelect = true;
		} else if (self.stereotype === 'dropdown') {
			self.isDropdown = true;
		} else if (self.stereotype === 'autocomplete') {
			self.isAutocomplete = true;
		} else if (self.stereotype === 'switch') {
			self.isSwitch = true;
		} else if (self.stereotype === 'equation') {
			self.isEquation = true;
		} else if (!self.stereotype) {
			self.isCustom = true;
		}
	};

	/*function runValidators($parse, $scope, gxFormService, feedbackType, modelValue, viewValue) {
		var result = [];
		gxFormService.resetValidators($scope.$ctrl.formName);
		for (var validatorKey in $scope.$ctrl.validatorsDefinitions[feedbackType]) {
			var validatorDefinition = $scope.$ctrl.validatorsDefinitions[feedbackType][validatorKey];
			if ((!!validatorDefinition.force && validatorDefinition.force === true) || gxFormService.isValidable($scope.$ctrl.formName, $scope.$ctrl.ngModelController)) {
				if (feedbackType != gxFormService.ERROR_FEEDBACK_TYPE
					&& !!validatorDefinition.validatorFunction
					&& !$parse(validatorDefinition.validatorFunction)($scope.$parent, { modelValue: modelValue, viewValue: viewValue })) {
					gxFormService.setValidatorInvalid($scope.$ctrl.formName, feedbackType, validatorKey, $scope.$ctrl.ngModelController, validatorDefinition.timeout);
				}
				if (!gxFormService.isValid($scope.$ctrl.formName, feedbackType, validatorKey, $scope.$ctrl.ngModelController)) {
					result.push(validatorDefinition);
				}
			}
		}
		return result;
	}*/

	/*function getFeedbackMessages($parse, $scope, validatorsDefinitions, modelValue, viewValue) {
		var feedbackMessages = [];
		angular.forEach(validatorsDefinitions, function (validatorDefinition) {
			var message = $scope.$ctrl.validatorsDefinitions[validatorDefinition.type][validatorDefinition.key].message;
			var messageText = null;
			var messageTimeout = $scope.$ctrl.validatorsDefinitions[validatorDefinition.type][validatorDefinition.key].timeout;
			try {
				messageText = $parse(message)($scope.$parent, { modelValue: modelValue, viewValue: viewValue });
			} catch (error) {
				messageText = message;
			}
			if (!messageText) {
				messageText = 'Menssagem de feedback não definida para o validador: ' + key;
			}
			feedbackMessages.push({ text: messageText, timeout: messageTimeout });
		}, feedbackMessages);
		return feedbackMessages;
	}*/

	// TRUE it is valid
	// FALSE it is invalid
	/*function validate($parse, $scope, gxFormService, feedbackType, modelValue, viewValue) {
		var result = true;
		var self = $scope.$ctrl;
		var invalidValidators = runValidators($parse, $scope, gxFormService, feedbackType, modelValue, viewValue);
		if (!!invalidValidators && invalidValidators.length > 0) {
			$scope.$ctrl.feedbackType = feedbackType;
			$scope.$ctrl.feedbackMessages = getFeedbackMessages($parse, $scope, invalidValidators, modelValue, viewValue);
			result = false;
		} else {
			$scope.$ctrl.feedbackType = gxFormService.DEFAULT_FEEDBACK_TYPE;
		}
		return result;
	};*/

	/*function initFeedback($timeout, $parse, $scope, gxFormService) {



		self.validate = function (modelValue, viewValue) {
			self.feedbackMessages = [];
			var result = validate($parse, $scope, gxFormService, gxFormService.ERROR_FEEDBACK_TYPE, modelValue, viewValue)
				&& validate($parse, $scope, gxFormService, gxFormService.WARNING_FEEDBACK_TYPE, modelValue, viewValue)
				&& validate($parse, $scope, gxFormService, gxFormService.SUCCESS_FEEDBACK_TYPE, modelValue, viewValue)
				&& validate($parse, $scope, gxFormService, gxFormService.INFO_FEEDBACK_TYPE, modelValue, viewValue);
			return true;
		};

		self.ngModelController.$validators.gxFormGroup = self.validate;*/

	/*self.element.on('blur', function () {
		for (var i = 0; i < self.feedbackMessages.length; i++) {
			var feedbackMessage = self.feedbackMessages[i];
			if (!!feedbackMessage.timeout) {
				$timeout(function () {
					var index = self.feedbackMessages.indexOf(feedbackMessage);
					if (index !== -1) {
						self.feedbackMessages.splice(index, 1);
					}
					if (self.feedbackMessages.length == 0) {
						self.feedbackType = gxFormService.DEFAULT_FEEDBACK_TYPE;
					}
				}, feedbackMessage.timeout);
			}
		}
	});
}*/

	function getFeedbackMessageIndex(feedbackMessages, feedbackMessage) {
		var index = -1;
		for (var i = 0; feedbackMessages.length > i; i++) {
			if (feedbackMessages[i].type === feedbackMessage.type
				&& feedbackMessages[i].key === feedbackMessage.key) {
				index = i;
				break;
			}
		}
		return index;
	}

	function removeFeedback($scope, gxFormService, feedbackMessages, feedbackMessage) {
		var index = getFeedbackMessageIndex(feedbackMessages, feedbackMessage);
		if (index > -1) {
			feedbackMessages.splice(index, 1);
		}
		gxFormService.setValidatorValid($scope.$ctrl.formName, feedbackMessage.type, feedbackMessage.key, $scope.ngModelController);
		if (feedbackMessages.length == 0) {
			$scope.$ctrl.feedbackType = gxFormService.DEFAULT_FEEDBACK_TYPE;
		}
	}

	function addFeedback(feedbackMessages, feedbackMessage) {
		var index = getFeedbackMessageIndex(feedbackMessages, feedbackMessage);
		if (index > -1) {
			feedbackMessages[index] = feedbackMessage;
		} else {
			feedbackMessages.push(feedbackMessage);
		}
	}

	function gxFormGroupController($timeout, $parse, $element, $scope, gxFormService) {

		var self = this;

		setName(self);
		setType(self);
		self.formName = $element.closest('form').attr('name');

		self.validatorsDefinitions = {}
		self.validatorsDefinitions[gxFormService.ERROR_FEEDBACK_TYPE] = {
			text: { type: "$error", key: "text", message: "Texto inválido" },
			number: { type: "$error", key: "number", message: "Numero inválido" },
			url: { type: "$error", key: "url", message: "URL Inválida" },
			email: { type: "$error", key: "email", message: "Email inválido" },
			date: { type: "$error", key: "date", message: "Data inválida" },
			radio: { type: "$error", key: "radio", message: "Radio inválido" },
			checkbox: { type: "$error", key: "checkbox", message: "Checkbox inválido" },
			required: { type: "$error", key: "required", message: "Campo obrigatório" },
			pattern: { type: "$error", key: "pattern", message: "O texto não segue o padrão definido" },
			minlength: { type: "$error", key: "minlength", message: "O texto não possui o tamanho mínimo de caracteres" },
			maxlength: { type: "$error", key: "maxlength", message: "O texto ultrapassa o tamanho máximo de caracteres" },
			min: { type: "$error", key: "min", message: "Numero inferior ao valor mínimo requerido" },
			max: { type: "$error", key: "max", message: "Numero superior ao valor mínimo requerido" }
		};
		self.validatorsDefinitions[gxFormService.WARNING_FEEDBACK_TYPE] = {};
		self.validatorsDefinitions[gxFormService.SUCCESS_FEEDBACK_TYPE] = {};
		self.validatorsDefinitions[gxFormService.INFO_FEEDBACK_TYPE] = {};

		self.ngModelController = null;

		self.registerNgModelController = function (ngModelController) {

			self.ngModelController = ngModelController;
			self.feedbackType = gxFormService.DEFAULT_FEEDBACK_TYPE;

			self.hasError = function () {
				return self.feedbackType === gxFormService.ERROR_FEEDBACK_TYPE;
			};

			self.hasWarning = function () {
				return self.feedbackType === gxFormService.WARNING_FEEDBACK_TYPE;
			};

			self.hasSuccess = function () {
				return self.feedbackType === gxFormService.SUCCESS_FEEDBACK_TYPE;
			};

			self.feedbackMessages = [];

			for (var feedbackType in self.validatorsDefinitions) {

				var feedback = self.validatorsDefinitions[feedbackType];

				for (var validatorKey in feedback) {

					var validatorDefinition = feedback[validatorKey];

					var validatorKey = null;
					if (!validatorDefinition.validatorFunction) {
						validatorKey = validatorDefinition.key + "Message";
					} else {
						validatorKey = validatorDefinition.key;
					}

					self.ngModelController.$validators[validatorKey] = function (modelValue, viewValue) {

						var result = true;

						var validable = ((!!validatorDefinition.force && validatorDefinition.force === true)
							|| gxFormService.isValidable($scope.$ctrl.formName, $scope.$ctrl.ngModelController));

						if (!validable) {
							return result;
						}

						var validadorFunction = validatorDefinition.validatorFunction;

						if (validatorDefinition.validatorFunction) {
							result = $parse(validatorDefinition.validatorFunction)($scope.$parent, {
								modelValue: modelValue,
								viewValue: viewValue
							});
						} else {
							result = gxFormService.isValid(self.formName, validatorDefinition.type, validatorDefinition.key, self.ngModelController);
						}

						if (!result) {

							self.feedbackType = feedbackType;

							var messageText = null;

							try {
								messageText = $parse(validatorDefinition.message)($scope.$parent, { modelValue: modelValue, viewValue: viewValue });
							} catch (error) {
								messageText = validatorDefinition.message;
							}

							if (!messageText) {
								messageText = 'Menssagem de feedback não definida para o validador: ' + key;
							}

							var feedbackMessage = {
								type: validatorDefinition.type,
								key: validatorDefinition.key,
								text: messageText,
								timeout: validatorDefinition.timeout
							}
							addFeedback(self.feedbackMessages, feedbackMessage)

							if (!!validatorDefinition.timeout) {
								$timeout(function () {
									removeFeedback($scope, gxFormService, self.feedbackMessages, feedbackMessage)
								}, validatorDefinition.timeout);
							}

						} else {
							removeFeedback($scope, gxFormService, self.feedbackMessages, {
								type: validatorDefinition.type,
								key: validatorDefinition.key
							});
						}

						if (validatorDefinition.type != gxFormService.ERROR_FEEDBACK_TYPE) {
							result = true;
						}

						return result;
					}
				}
			}
		};

		self.registerValidator = function (feedbackType, validatorKey, validatorFunction, force, message, timeout) {
			self.validatorsDefinitions[feedbackType][validatorKey] = {
				type: feedbackType,
				key: validatorKey,
				validatorFunction: validatorFunction,
				force: force,
				message: message,
				timeout: timeout
			};
		};

		self.setModel = function (model, force) {
			self.model = model;
			if (gxForceValidation === true) {
				$scope.$apply();
			}
		};

		self.getBadgeValue = function (item) {
			var badgePathArray = self.modelOptionAttributeBadge.split('.');
			var result = item;
			for (var i = 0; i < badgePathArray.length; i++) {
				result = result[badgePathArray[i]];
			}
			return result;
		};

		if (self.isSelect) {

			$scope.$watch('$ctrl.modelOptions', function (newValue, oldValue) {
				if (self.modelOptions) {
					self.selectModelOptions = self.modelOptions.slice(0);
				} else {
					self.selectModelOptions = null;
				}
			});

			$scope.$watch('$ctrl.model', function (newValue, oldValue) {
				if (newValue) {
					self.selectModel = self.model;
				} else if (self.selectModel) {
					self.selectModel = null;
				}
			});

			$scope.$watch('$ctrl.selectModel', function (newValue, oldValue) {
				if (newValue) {
					self.model = newValue;
				} else if (self.model) {
					self.model = null;
				}
			});
		}
	};

	var gxFormGroupDependencies = [
		'gux.tooltip',
		'ui.mask',
		'gux.formGroupTarget',
		'gux.formGroupInput',
		'gux.formGroupTextarea',
		'gux.formGroupCalendar',
		'gux.formGroupSelect',
		'gux.formGroupDropdown',
		'gux.formGroupAutocomplete',
		'gux.formGroupSwitch',
		'gux.formGroupEquation',
		'gux.formGroupValidator'
	];

	var gxFormGroupComponent = {
		templateUrl: 'views/gx-form-group.html',
		transclude: {
			'gxFormGroupValidator': '?gxFormGroupValidator'
		},
		require: {
			gxFormController: '^gxForm'
		},
		bindings: {
			name: '@',
			stereotype: '@',
			label: '@',
			offLabel: '@',
			onLabel: '@',
			description: '@',
			example: '@',
			mask: '@',
			model: '=',
			modelOffValue: '@',
			modelOnValue: '@',
			modelOptions: '=',
			modelOptionAttributeKey: '@',
			modelOptionAttributeValue: '@',
			modelOptionAttributeBadge: '@',
			gxRows: '@',
			gxCols: '@',
			minlength: '@',
			maxlength: '@',
			min: '@',
			max: '@',
			pattern: '@',
			tabindex: '@',
			required: '=',
			readonly: '@',
			disabled: '=',
			ignoreTimezone: '@',
			gxCalPlacement: '@',
			onCreate: '&',
			onUpdate: '&',
			onDelete: '&',
			gxErrorValidator: '@',
			gxWarningValidator: '@',
			gxMessage: '@',
			gxMessages: '=',
			gxForceValidation: '@'
		},
		controller: [
			'$timeout',
			'$parse',
			'$element',
			'$scope',
			'gxFormService',
			gxFormGroupController
		]
	};

	function gxFormGroupRun(uiMaskConfig) {
		uiMaskConfig.clearOnBlur = false;
	}

	angular
		.module('gux.formGroup', gxFormGroupDependencies)
		.component('gxFormGroup', gxFormGroupComponent)
		.run(['uiMaskConfig', gxFormGroupRun]);

} (window.$, window.angular));
