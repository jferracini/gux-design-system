(function ($, angular) {

	'use strict';

	function gxFormGroupValidatorController($element, gxFormService) {
		this.$onInit = function() {
			var type = !!this.gxType ? this.gxType : 'error';
			if(type.toUpperCase().indexOf('ERROR') > -1) {
				type = gxFormService.ERROR_FEEDBACK_TYPE;
			} else if (type.toUpperCase().indexOf('WARNING') > -1) {
				type = gxFormService.WARNING_FEEDBACK_TYPE;
			} else if (type.toUpperCase().indexOf('SUCCESS') > -1) {
				type = gxFormService.SUCCESS_FEEDBACK_TYPE;
			} else if (type.toUpperCase().indexOf('INFO') > -1) {
				type = gxFormService.INFO_FEEDBACK_TYPE;
			}
			var key = !!this.gxKey ? this.gxKey : 'default';
			var message = $element.html();
			if (!this.gxMessage) {
				throw new Error('You must define gx-message attribute for element ' + $('<span>').append($element).html());
			}
			var validatorFunction = this.gxFunction;
			if(type != gxFormService.ERROR_FEEDBACK_TYPE && !validatorFunction) {
				throw new Error('You must define gx-function attribute for element ' + $('<span>').append($element).html());
			}
			var force = false;
			if (!!this.gxForce && (this.gxForce === "true" || this.gxForce === true)) {
				force = true;
			}
			this.gxFormGroupController.registerValidator(type, key, validatorFunction, force, this.gxMessage, this.gxTimeout);
		}
	}

	var gxFormGroupValidatorDependencies = [];

	var gxFormGroupValidatorComponent = {
		require: {
			gxFormGroupController: '^gxFormGroup'
		},
		bindings: {
			gxType: '@',
			gxKey: '@',
			gxFunction: '@',
			gxForce: '@',
			gxMessage: '@',
			gxTimeout: '@'
		},
		controller: [
			'$element',
			'gxFormService',
			gxFormGroupValidatorController
		]
	};
	angular
		.module('gux.formGroupValidator', gxFormGroupValidatorDependencies)
		.component('gxFormGroupValidator', gxFormGroupValidatorComponent);

} (window.$, window.angular));
