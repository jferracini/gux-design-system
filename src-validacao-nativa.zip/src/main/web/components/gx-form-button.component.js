(function (angular) {

    'use strict';

    function gxFormButtonController($parse, $state, $element, $scope, gxAppService, gxFormService) {

        var formName = $element.closest('form').attr('name');

        var self = this;

        if (self.stereotype === 'post') {
            self.type = "submit";
            self.buttonClass = "btn-success";
            self.iconClass = "fa-save";
            self.label = "Gravar";
        } else if (self.stereotype === 'put') {
            self.type = "submit";
            self.buttonClass = "btn-success";
            self.iconClass = "fa-save";
            self.label = "Atualizar";
        } else if (self.stereotype === 'get') {
            self.type = "submit";
            self.buttonClass = "btn-primary";
            self.iconClass = "fa-search";
            self.label = "Pesquisar";
        } else if (self.stereotype === 'clean') {
            self.type = "reset";
            self.buttonClass = "btn-default";
            self.iconClass = "fa-eraser";
            self.label = "Limpar";
        } else if (self.stereotype === 'cancel') {
            self.type = "button";
            self.buttonClass = "";
            self.iconClass = "fa-ban";
            self.label = "Cancelar";
        } else if (self.stereotype === 'back') {
            self.type = "button";
            self.buttonClass = "btn-default";
            self.iconClass = "fa-long-arrow-left";
            self.label = "Voltar";
        }

        self.click = function () {

            var result = undefined;

            if (!gxFormService.isForce(formName) && !gxFormService.isValid(formName)) {
                return;
            }

            if (!!self.onClick) {
                result = $parse(self.onClick)($scope.$parent);
            }

            if (!!self.go) {
                $state.go(controller.go);
            } else if (self.stereotype === 'cancel'
                || self.stereotype === 'back') {
                var lastState = gxAppService.getLastState();
                if (!!lastState) {
                    $state.go(lastState.name);
                }
            }

            if (self.stereotype === 'clean') {
                gxFormService.$setPristine(formName);
            }

            return result;
        };

        self.isDisabled = function () {
            var disabled = false;
            if (self.stereotype === 'cancel'
                || controller.stereotype === 'back') {
                if (!gxAppService.getLastState()) {
                    disabled = true;
                }
            }
            return disabled;
        }
    };

    var gxFormButtonDependencies = [
        'ui.router'
    ];

    var gxFormButtonComponent = {
        templateUrl: 'views/gx-form-button.html',
        bindings: {
            stereotype: '@',
            go: '@',
            onClick: '&'
        },
        controller: [
            '$parse',
            '$state',
            '$element',
            '$scope',
            'gxAppService',
            'gxFormService',
            gxFormButtonController
        ]
    };

    angular
        .module('gux.formButton', gxFormButtonDependencies)
        .component('gxFormButton', gxFormButtonComponent);

} (window.angular));
