(function (angular) {

	'use strict';

	angular.module('gux.test.home', ['gux.toolbox', 'gux.test.services']);

} (window.angular));
