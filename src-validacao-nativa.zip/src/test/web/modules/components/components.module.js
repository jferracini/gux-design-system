(function (angular) {

	'use strict';
	
	var componentsDpendencies = [
		'gux.toolbox',
		'ui.codemirror',
		'gux.test.services'
	];

	angular.module('gux.test.components', componentsDpendencies);

} (window.angular));
