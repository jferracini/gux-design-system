(function (angular) {

	'use strict';

	angular.module('gux.test.layouts', [
		'gux.toolbox',
		'gux.test.services']);

} (window.angular));
