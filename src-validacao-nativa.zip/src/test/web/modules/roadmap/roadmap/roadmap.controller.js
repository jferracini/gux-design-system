(function (angular) {

	'use strict';

	function roadmapController() {
		
	}

	angular.module('gux.test.roadmap')
		.controller('RoadmapController', [roadmapController]);

}(window.angular));
