(function (angular) {

	'use strict';

	angular.module('gux.test.roadmap', ['gux.toolbox']);

} (window.angular));
