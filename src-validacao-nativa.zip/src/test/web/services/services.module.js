(function (angular) {
	
	'use strict';
	
	angular.module('gux.test.services', [])

} (window.angular));